// static/js/tabs_and_twin.js
(() => {
  // ---------- Tabs (피그마처럼 화면 전환) ----------
  const tabBtns = document.querySelectorAll(".tab-btn");
  const views = document.querySelectorAll("[data-view]");

  function activate(tabName){
    tabBtns.forEach(b => b.dataset.active = (b.dataset.tab === tabName ? "true" : "false"));
    views.forEach(v => v.classList.toggle("active", v.dataset.view === tabName));
  }

  tabBtns.forEach(btn => {
    btn.addEventListener("click", () => activate(btn.dataset.tab));
  });

  // ---------- Twin (공정흐름 섹션) ----------
  const stage = document.getElementById("twinStage");
  const sidebar = document.getElementById("twinSidebar");
  const closePanelBtn = document.getElementById("closePanelBtn");

  const titleEl = document.getElementById("twinTitle");
  const moduleTagEl = document.getElementById("twinModuleTag");
  const inputEl = document.getElementById("twinInput");
  const runBtn = document.getElementById("runAnalyzeBtn");

  const resultWrap = document.getElementById("twinResult");
  const statusEl = document.getElementById("twinStatusText");

  let selectedModule = null;
  let twinChart = null;

  function openPanel(moduleName){
    selectedModule = moduleName;
    titleEl.textContent = `${moduleName} 공정 리포트`;
    moduleTagEl.textContent = moduleName;

    sidebar.classList.add("active");
    stage.classList.add("panel-open");

    sidebar.classList.remove("expanded");
    resultWrap.style.display = "none";
    statusEl.textContent = "상태: -";
    inputEl.value = "";

    setTimeout(() => inputEl.focus(), 250);
  }

  function closePanel(){
    sidebar.classList.remove("active", "expanded");
    stage.classList.remove("panel-open");
    resultWrap.style.display = "none";
    selectedModule = null;
  }

  async function requestAnalysis(){
    const val = inputEl.value;
    if (!selectedModule || val === "" || val === null) return;

    sidebar.classList.add("expanded");
    resultWrap.style.display = "block";

    let resJson;
    try{
      const res = await fetch("/api/analyze", {
        method:"POST",
        headers:{ "Content-Type":"application/json" },
        body: JSON.stringify({ module: selectedModule, value: val })
      });
      resJson = await res.json();
    }catch(e){
      statusEl.textContent = "상태: API 호출 실패";
      return;
    }

    statusEl.textContent = `상태: ${resJson.status || "-"}`;
    drawTwinChart(resJson.labels || [], resJson.trend || []);
  }

  function drawTwinChart(labels, trend){
    const canvas = document.getElementById("twinChart");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");

    if (twinChart) twinChart.destroy();

    twinChart = new Chart(ctx, {
      type:"line",
      data:{
        labels,
        datasets:[{
          data: trend,
          borderColor:"#00e5ff",
          pointBackgroundColor:"#00e5ff",
          backgroundColor:"rgba(0,229,255,0.06)",
          borderWidth:2,
          tension:0.4,
          pointRadius:3,
          fill:true,
        }]
      },
      options:{
        responsive:true,
        maintainAspectRatio:false,
        plugins:{ legend:{ display:false } },
        scales:{
          x:{ ticks:{ color:"rgba(255,255,255,0.0)" }, grid:{ display:false } },
          y:{ ticks:{ color:"rgba(255,255,255,0.0)" }, grid:{ color:"rgba(255,255,255,0.06)" } }
        }
      }
    });
  }

  // 이벤트
  closePanelBtn?.addEventListener("click", closePanel);
  runBtn?.addEventListener("click", requestAnalysis);
  inputEl?.addEventListener("keydown", (e) => { if (e.key === "Enter") requestAnalysis(); });

  document.querySelectorAll(".clickable-area").forEach(el => {
    el.addEventListener("click", () => {
      // 공정 흐름 탭으로 자동 이동 (피그마 UX에 더 가까움)
      activate("process");
      openPanel(el.getAttribute("data-module"));
    });
  });
})();

